#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#define ll malloc(sizeof(node)) 
typedef struct node{
	int data;
	struct node *link;
}node;
void createList(node *head){
	printf("\nEnter data at head:");
	scanf("%d",&head->data);
	head->link=NULL;
}

void AddTail(node *head){
	if(head==NULL){
		printf("\nList Empty");
		return;
	}
	node *ptr=ll;
	node *temp=ll;
	
	printf("\nEnter data at tail:");
	scanf("%d",&temp->data);
	temp->link=NULL;
	
	ptr=head;
	while(ptr->link!=NULL){
		ptr=ptr->link;
	}
	ptr->link=temp;
}
void display(int *head){
	node *curr=ll;
	curr=head;
	printf("\n");
		while(curr){
		printf("%d->",curr->data);
		curr =curr->link;
		if(curr==NULL)
		printf("NULL");
	}
}
void AddBeginning(node **head){
	if(head==NULL){
		printf("\nList Empty");
		return;
	}
	node *begin=ll;
	printf("\nEnter data at beginning:");
	scanf("%d",&begin->data);
	begin->link=*head;
	
	*head=begin;
}
void AddkthNode(node *head,int k){
	if(head==NULL){
		printf("\nList Empty");
		return;
	}
	node *ptr=ll;
	node *ptr2=ll;
	printf("\nEnter data:");
	scanf("%d",&ptr2->data);
	ptr2->link=NULL;
	int i=1;
	ptr=head;
	while(k!=2){
		ptr=ptr->link;
		k--;
	}
	ptr2->link=ptr->link;
	ptr->link=ptr2;
}
void InsertNodeAfterNode(node *head,int n){
	if(head==NULL){
		printf("\nList Empty");
		return;
	}
	node *ptr=head;
	node *ptr2=ll;
	ptr=head;
	while(ptr->data!=n){
		ptr=ptr->link;
		if(ptr->link==NULL){
		printf("\nNode not present");
		return;
	}
	}
	printf("\nEnter node data:");
	scanf("%d",&ptr2->data);
	
	ptr2->link=ptr->link;
	ptr->link=ptr2;
	
}
void InsertNodeBeforeNode(node *head,int n){
	node *ptr=head;
	node *ptr2=ll;
	int pos=1;
	while(ptr->data!=n){
		ptr=ptr->link;
		pos++;
		if(ptr->link==NULL){
		printf("\nNode not present");
		return;
	}
	}
	AddkthNode(head,pos);
}
node* DeleteHead(node *head){
	if(head==NULL){
		printf("\nList Empty");
		return;
	}
	else{
	node *temp=head;
	head=head->link;
	free(temp);
	temp=NULL;
}
return head;	
}
void DeleteEnd(node* head){
	if(head==NULL){
		printf("\nList Empty");
		return;
	}
	else if(head->link==NULL){
		free(head);
		head=NULL;
	}
	node* ptr=head;
	
	while(ptr->link->link!=NULL){
		ptr=ptr->link;
	}
	free(ptr->link);
	ptr->link=NULL;
}
void DeletekthNode(node* head,int k){
	node* temp=head;
	node* temp2=head;
	while(k!=2){
		temp=temp->link;
		temp2=temp->link;
		k--;
	}
	if(temp->link==NULL){
			DeleteEnd(head);
			return;
		}
	temp->link=temp2->link;
	free(temp2);
	temp2=NULL;	
}
void DeleteNodeAfterNode(node *head,int n){
	int k=1;
	node *ptr=head;
	while(ptr->data!=n){
		ptr=ptr->link;
		k++;
	}
	DeletekthNode(head,k);
}
node* reverseList(node *head){
	node* prev=NULL;
	node* next=NULL;
	while(head!=NULL){
		next=head->link;
		head->link=prev;
		prev=head;
		head=next;
	}
	head=prev;
}
void SearchNode(node* head,int n){
	node* ptr=head;
	int k=1;
	while(ptr->data!=n){
		ptr=ptr->link;
		if(ptr==NULL){
			printf("\nNode not present");
			return;
		}
		k++;
	}
	printf("\nNode found at index: %d",k);
	return;
	
}
void BubbleSort(node *start)
{
    int swapped, i;
    node *ptr1;
    node *lptr = NULL;
  
    /* Checking for empty list */
    if (start == NULL)
        return;
  
    do
    {
        swapped = 0;
        ptr1 = start;
  
        while (ptr1->link != lptr)
        {
            if (ptr1->data > ptr1->link->data)
            { 
                swap(ptr1, ptr1->link);
                swapped = 1;
            }
            ptr1 = ptr1->link;
        }
        lptr = ptr1;
    }
    while (swapped);
}
void swap(node *a, node *b)
{
    int temp = a->data;
    a->data = b->data;
    b->data = temp;
}
node* SortedMerge(node* a, node* b) 
{
  node* result = NULL;
    
  /* point to the last result pointer */
  node** lastPtrRef = &result; 
    
  while(1) 
  {
    if (a == NULL) 
    {
      *lastPtrRef = b;
       break;
    }
    else if (b==NULL) 
    {
       *lastPtrRef = a;
       break;
    }
    if(a->data <= b->data) 
    {
      MoveNode(lastPtrRef, &a);
    }
    else 
    {
      MoveNode(lastPtrRef, &b);
    }
    lastPtrRef = &((*lastPtrRef)->link); 
  }
  return(result);
}
void MoveNode(node** destRef, node** sourceRef)
{
    /* the front source node  */
    node* newNode = *sourceRef;
    assert(newNode != NULL);
  
    /* Advance the source pointer */
    *sourceRef = newNode->link;
  
    /* Link the old dest off the new node */
    newNode->link = *destRef;
  
    /* Move dest to point to the new node */
    *destRef = newNode;
}
node * ConCatLists(node *head1, node *head2)
{
                node*p;
                if (head1==NULL)                            //if the first linkedlist is empty
                return(head2);
                if (head2==NULL)                            //if second linkedlist is empty
                 return(head1);
               
                p=head1;                             //place p on the firstnode of the first linked list
               
                while (p->link!=NULL)                 //move p to the last node
                p=p->link;
                p->link=head2;    //address of the first node of the second linked list stored in the last node of thefirst linked list
                
                return(head1);
}
void CheckEquality(node* head1,node *head2){
	int c1=1,c2=1;
	node* ptr1=head1;
	node* ptr2=head2;
	while(ptr1!=NULL){
		c1++;
		ptr1=ptr1->link;
	}
	while(ptr2!=NULL){
		c2++;
		ptr2=ptr2->link;
	}
	if(c1==c2){
	while(ptr1!=NULL && ptr2!=NULL){
		if(ptr1->data!=ptr2->data){
		printf("\nLINK LISTS ARE Not Equal");
		return;
	}
	ptr1=ptr1->link;
	ptr2=ptr2->link;
	}
	printf("\nLINK LISTS ARE EQUAL");
}
else
printf("\nLink Lists are Not Equal");
}
int main(){
	int n,ch,k,nv,lc;
	node *head=ll;
	node* head2=ll;
	do{
	  printf("\n\nChoices Available: \n1.Create Link List\t\t2.Print list\n3.Insert at beginning\t\t4.Insert at end\n5.Insert after k-th position\t6.Insert node after a given node\n7.Insert node before kth node\t8.Insert node before a given node\n9.Delete beginning\t\t10.Delete End\n11.Delete node after kth node\t12.Delete node before kth node\n13.Delete kth node\t\t14.Delete node containing a specified value\n15.Reverse the list\t\t16.Sort the list\n17.Search given element\t\t18.Merge two lists\n19.Concatenate 2 lists\t\t20.Check if 2 lists are equal\n21.Exit");	
	printf("\nEnter Choice:");
	scanf("%d",&ch);
	switch(ch){
		case 1:printf("\nEnter index of list to be created:");
				scanf("%d",&lc);
				if(lc==1){
					createList(head);
					break;
				}
				else if(lc==2);
				createList(head2);
				break;
				
		case 2:printf("\nEnter index of list to be displayed:");
				scanf("%d",&lc);
				if(lc==1){
					display(head);
					break;
				}
				else if(lc==2);
				display(head2);
				break;
				
		case 3:printf("\nEnter index of list to be inserted:");
				scanf("%d",&lc);
				if(lc==1){
					AddBeginning(&head);
					break;
				}
				else if(lc==2);
				AddBeginning(&head2);
				break;
			
		case 4: 
		        printf("\nEnter index of lists to be inserted:");
				scanf("%d",&lc);
				if(lc==1){
					printf("\nEnter the number of nodes:");
                scanf("%d",&n); 
                	while(n>0){
				AddTail(head);
				n--;
				} 
					break;
				}
				else if(lc==2);
				{
					printf("\nEnter the number of nodes:");
                scanf("%d",&n); 
                	while(n>0){
				AddTail(head2);
				n--;
				} 
				}
				break;
		
		case 5:printf("\nEnter the value of k:");
		       scanf("%d",&k);
		       AddkthNode(head,k+1);
		       break;
		
		case 6:printf("\nEnter Node Value:");
				scanf("%d",&nv);
				InsertNodeAfterNode(head,nv);
				break;
				
		case 7:printf("\nEnter the value of k:");
		       scanf("%d",&k);
		       if(k==1){
		       	AddBeginning(&head);
			   }
			   else
			   AddkthNode(head,k-1);
			   break;
		
		case 8:printf("\nEnter node value:");
		       scanf("%d",&nv);
		       if(nv==head->data){
		       	printf("\nEntered value is at head\n");
		       	AddBeginning(&head);
			   }
			   else
		       InsertNodeBeforeNode(head,nv);
		       break;
		       
		case 9:head=DeleteHead(head);
		       break;
		
		case 10:DeleteEnd(head);
		        break;
		
		case 11:printf("\nEnter the value of k:");
		        scanf("%d",&k);
		        if(k==0){
		        	head=DeleteHead(head);
				}
				else{
					DeletekthNode(head,k+1);
				}
				break;
		
		case 12:printf("\nEnter the value of k:");
		        scanf("%d",&k);
				DeletekthNode(head,k-1);
				break;
		
		case 13:printf("\nEnter the value of k:");
		        scanf("%d",&k);
		        if(k==1){
		        	head=DeleteHead(head);
				}
				else
				DeletekthNode(head,k);
				break;
				
		case 14:printf("\nEnter node value:");
		        scanf("%d",&nv);
		        DeleteNodeAfterNode(head,nv);
		        break;
				
		case 15:head=reverseList(head);
		        break;
		
		case 16:BubbleSort(head);
		        break;
		
		case 17:printf("\nEnter Node value:");
		        scanf("%d",&nv);
		        SearchNode(head,nv);
		        break;
		        
	    case 18:BubbleSort(head);BubbleSort(head2);
	            head=SortedMerge(head,head2);
	            display(head);
	            break;
	    
	    case 19:head=ConCatLists(head,head2);
	            display(head);
	            break;
	            
	    case 20:CheckEquality(head,head2);
	            break;
	            
	    case 21:exit(1);
	            
		default:printf("\nINVALID choice");
		        break;
				
	}
	}while(ch>=1&&ch<=21);
   
    
	return 0;

}
