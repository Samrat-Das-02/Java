import java.util.*;
import java.io.*;

class Student{
    private int roll;
    private String name;
    private double score;
    public Student(int roll,String name,double score){
        this.roll=roll;
        this.score=score;
        this.name=name;
    }
    public String toString(){
        return "Student's Name:"+this.name+"\tStudent's Roll:"+this.roll+"\tStudent's Score:"+this.score;
    }
}


class ObjectFileProcessing {
    public void storeObject(Student stu){        
       try {
        BufferedWriter out = new BufferedWriter(new FileWriter("StuFile.txt", true));
        out.write(""+stu+"\n");
        out.close();
       } catch (Exception e) {
           e.printStackTrace();
       }
   }
  
   public void displayObjects(){         
       try {
        BufferedReader in = new BufferedReader(new FileReader("StuFile.txt"));

        String mystring;
        
        while ((mystring = in.readLine()) != null) {
            System.out.println(mystring);
        }
       } 
       catch (Exception e) {
           e.printStackTrace();   
       } 
   }
}

public class Java3_5{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> arr=new ArrayList<Integer>();
        System.out.print("Enter number of students:");
        int n=sc.nextInt();
        Student s[]=new Student[n];   
        ObjectFileProcessing obj = new ObjectFileProcessing();
        for(int i=0;i<n;i++){
            System.out.println("Student "+(i+1));
            System.out.print("Enter Roll:");
            int roll=sc.nextInt();
            if(arr.isEmpty()){
                arr.add(roll);
            }
            else if(arr.contains(roll)){
                System.out.print("Roll number must be unique...Re enter roll number:");
                roll=sc.nextInt();
            }
            System.out.println("Enter name:");
            sc.nextLine();
            String name=sc.nextLine();
            System.out.print("Enter score:");
            double score=sc.nextDouble();
            s[i]=new Student(roll,name,score);
            obj.storeObject(s[i]);
        }
        obj.displayObjects();
    }
}
