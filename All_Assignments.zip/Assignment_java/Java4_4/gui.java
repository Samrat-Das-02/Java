/*
Consider an employee has empcode (unique),empname, basic salary, grade, dept code. Develop GUI based application 
for the following:
a) Develop GUI to accept data from user. For dept code, a list of dept names are to be shown from user chooses 
one and corresponding dept code will be part of employee object. Grade is either A or B or C. Once user selects 
SAVE button, get confirmation from user and if confirmed object is to be stored in file/collection class 
(as you like). Ensure empcode is unique. For duplicate value a message dialog is to be displayed and it will 
not be stored.
b) Develop GUI that accepts an empcode from user. If SEARCH button is placed corresponding details are to be 
shown. If not found, display a message.
*/
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.table.*;
//Employee Class
class Employee{
    private String empcode;
    private String empname;
    private String salary;
    private String grade;
    private String dept_name;
    public Employee(String empcode,String empname,String salary,String grade,String dept_name){
        this.empcode=empcode;
        this.empname=empname;
        this.salary=salary;
        this.grade=grade;
        this.dept_name=dept_name;
    }
    public String get_empcode(){
        return this.empcode;
    }
    public String get_empname(){
        return this.empname;
    }
    public String get_salary(){
        return this.salary;
    }
    public String get_grade(){
        return this.grade;
    }
    public String get_deptname(){
        return this.dept_name;
    }
    public String toString(){
        return "Employee Code:"+this.empcode+"\nEmployee Name:"+this.empname+"\nSalary:"+this.salary+
        "\nGrade:"+this.grade+"\nDepartment Name:"+this.dept_name;
    }
}
//gui class to create gui objects
class gui {
    JFrame f,f1;         //window creation
    JPanel p1,p2,p3;     //window tab creation
    JTabbedPane tp;      //to change window size dynamically
    JLabel l1, l2, l3, l4,l5,l6;
    JTextField tf1,tf2,tf3,tf6;
    JComboBox tf4,tf5;
    JScrollPane sp1;
    JTable jt;
    JButton savebtn,resetbtn,searchbtn,viewbtn;
    ArrayList<Employee> Emps=new ArrayList<Employee>();

    gui(){
        
        f=new JFrame("GUI PROJECT");
        f1=new JFrame("Employee Records");

        p1=new JPanel(new GridLayout(6,2));
        p2=new JPanel();
        p3=new JPanel();

        tp=new JTabbedPane();
        l1=new JLabel("Employee Code:");
        l2=new JLabel("Employee Name:");
        l3=new JLabel("Basic Salary:");
        l4=new JLabel("Grade:");
        l5=new JLabel("Dept Code:");
        l6=new JLabel("Employee Code:");
        //setting bound of label panel2
        l6.setBounds(0,0,90,30);

        tf1=new JTextField(12);
        tf2=new JTextField(12);
        tf3=new JTextField(12);

        //creating drop down menu for grade
        String grades[]={"A","B","C"};
        tf4=new JComboBox(grades);
        //creating drop down menu for dept code
        String dcodes[]={"Research","Personnel","Finance","Purchase","Production"};
        tf5=new JComboBox(dcodes);

        tf6=new JTextField(12);
        //setting label for textfiels in panel2
        tf6.setBounds(0,90,90,30);

        savebtn=new JButton(" Save ");
        resetbtn=new JButton(" Reset ");
        searchbtn=new JButton(" Search ");
        //setting bounds of search button in panel2
        searchbtn.setBounds(90,30,30,30);

        //adding componenets to window frame
        //tab1 components
        p1.add(l1);
        p1.add(tf1);

        p1.add(l2);
        p1.add(tf2);

        p1.add(l3);
        p1.add(tf3);

        p1.add(l4);
        p1.add(tf4);

        p1.add(l5);
        p1.add(tf5);

        p1.add(savebtn);
        p1.add(resetbtn);

        //tab2 components
        p2.add(l6);
        p2.add(tf6);
        p2.add(searchbtn);

        //tab3 components
        viewbtn=new JButton(" View ");
        viewbtn.setBounds(90,30,30,30);
        p3.add(viewbtn);
        //JScrollPane sp2=new JScrollPane(jt);        

        //act on pressing reset button
        resetbtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ae){
                //reset text fields to empty string
                tf1.setText("");
                tf2.setText("");
                tf3.setText("");
                //reset drop down menu to 1st item of list
                tf4.setSelectedIndex(0);
                tf5.setSelectedIndex(0);
            }
        });
        //act on pressing save button
        savebtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae){
                String value1=tf1.getText();
                String value2=tf2.getText();
                String value3=tf3.getText();
                //get the selected value from dropdown menu
                String value4=(String)tf4.getItemAt(tf4.getSelectedIndex());   
                String value5=(String)tf5.getItemAt(tf5.getSelectedIndex()); 
                boolean flag=false;
                if(value1.equals("")){
                    JOptionPane.showMessageDialog(f, "Employee Code Cannot Be NULL");
                }
                else{
                    //loop to search empcode in the arraylist,if already present
                    for(int i=0;i<Emps.size();i++){
                        String temp=Emps.get(i).get_empcode();
                        if(temp.equals(value1)){
                            JOptionPane.showMessageDialog(f, "Employee Code Must be Unique!!!");
                            flag=true;
                            break;
                        }
                    }
                    if(!flag){
                        Employee e=new Employee(value1,value2,value3,value4,value5);
                        Emps.add(e);
                        //prints the last inserted record
                        //System.out.println(Emps.get(Emps.size()-1));
                    }
                }
                //reset text fields to empty string
                tf1.setText("");
                tf2.setText("");
                tf3.setText("");
                //reset drop down menu to 1st item of list
                tf4.setSelectedIndex(0);
                tf5.setSelectedIndex(0);
            }
        });
        //act on pressing search button
        searchbtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                String value1=tf6.getText();
                boolean flag=false;
                if(value1.equals("")){
                    JOptionPane.showMessageDialog(f, "Employee Code Cannot Be NULL");
                }
                else{
                    for(int i=0;i<Emps.size();i++){
                        Employee e=Emps.get(i);
                        String temp=e.get_empcode();
                        if(temp.equals(value1)){
                            JOptionPane.showMessageDialog(f, "Employee Has Found...\nDetails is:\n"+e);
                            flag=true;
                            break;
                        }
                    }
                    if(!flag){
                        JOptionPane.showMessageDialog(f, "Employee Has Not Found...");
                    }
                }
                tf6.setText("");
            }
        });
        //act on pressing view button
        viewbtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                f1.setSize(350,180);
                f1.setVisible(true);
                f1.setResizable(true);
                String[] columns={"Employee Code","Employee Name","Salray","Grade","Department Name"};
                DefaultTableModel model = new DefaultTableModel(columns,0);
                JTable table = new JTable();
                table.setModel(model);
                table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                table.setFillsViewportHeight(true);
                JScrollPane scroll = new JScrollPane(table);
                for(int i=0;i<Emps.size();i++){
                    Employee e=Emps.get(i);
                    model.addRow(new Object[]{
                         e.get_empcode(),e.get_empname(),e.get_salary(),e.get_grade(),e.get_deptname()
                   });
                }
                f1.add(scroll);
            }
        });
    }
    void dis()
    {
        f.getContentPane().add(tp);
        tp.addTab("Add Records",p1);
        tp.addTab("Search Records",p2);
        tp.addTab("View Records", p3);

        f.setSize(350,180);
        f.setVisible(true);
        f.setResizable(true);
        //closes the window on clicking cross symbol
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String args[]){
            gui pro=new gui();
            pro.dis();
        }
}

