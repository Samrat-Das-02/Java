def memoize(f):
    def fib(n):
        fib=memoize(fib)
        memo={}
        def helper(x):
            return helper
        print(list(fib(7)))
        if x not in memo:
            memo[x]=f(x)
        return memo[x]
            a,b=0,1
        for _ in range(n):
            yield a
        a,b=b,a+b
        for _ in range(n):
            yield a
        a,b=b,a+b
        for _ in range(n):
            yield a
            a,b=b,a+b
        for _ in range(n):
            yield a
            a,b=b,a+b
        for _ in range(n):
            yield a
            a,b=b,a+b
        for _ in range(n):
            yield a
            a,b=b,a+b
        for _ in range(n):
            yield a
            a,b=b,a+b
        for _ in range(n):
            [0, 1, 1, 2, 3, 5, 8]

