import java.util.Scanner;
//access class to create shared variable
class Access{
    public int x;
    public void set_x(int val){
        x=val;
    }
    void call(int step){
        x=x+step;
        System.out.println("X updated to:"+x);
    }
}
//creation of thread
class Caller implements Runnable{
    int step;
    Access target;
    Thread t;
    //constructor
    public Caller(Access targ,int s){
        step=s;
        target=targ;
        t=new Thread(this);
        t.start();  //initiating thread
    }
    //thread running method
    public void run(){
        target.call(step);
    }
}
public class Java4_1{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        Access target=new Access();
        System.out.println("Enter initial value of shared variable:");
        int val=sc.nextInt();
        target.set_x(val);
        System.out.println("Enter increment step size:");
        int step1=sc.nextInt();
        System.out.println("Enter decrement step size:");
        int step2=sc.nextInt();
        Caller ob1=new Caller(target,step1);
        Caller ob2=new Caller(target,-step2);
    }
}

