#include<stdio.h>
#include<stdlib.h>
//node structure for doubly linked list
typedef struct record{
int data;
struct record *prev,*next;
}node;
//method to create doubly linked list
void create(node **head,node **tail){
int op;
node *temp;
do{
temp=(node*)malloc(sizeof(node));
if(temp==NULL)
printf("\nMemory allocation is not possible!!!");
else
{
printf("\nEnter data:");
scanf("%d",&temp->data);
temp->next=NULL;
temp->prev=NULL;
if(*head==NULL&&*tail==NULL)
{
*head=temp;
*tail=temp;
}
else
{
temp->prev=*tail;
(*tail)->next=temp;
*tail=temp;
}
}
printf("\nEnter 1 to continue,else 0:");
scanf("%d",&op);
}while(op==1);
}
//method to display doubly linked list
void display(node *head,node *tail){
node *curr;
int ch;
//if list is not created
if(head==NULL&&tail==NULL){
printf("\nList is empty..");
}
else{
/*printf("\n1.Display from head\n2.Display from tail\nEnter your choice:");
scanf("%d",&ch);
//switch case to either display from left or from right
switch(ch){
case 1:
printf("\nThe list from head is:");
curr=head;
while(curr){
printf("%d\t",curr->data);
curr=curr->next;
}
break;
case 2:
printf("\nThe list from tail is:");
curr=tail;
while(curr){
printf("%d\t",curr->data);
curr=curr->prev;
}
break;
}*/
printf("\nThe list from head is:");
curr=head;
while(curr){
printf("%d\t",curr->data);
curr=curr->next;
}
printf("\nThe list from tail is:");
curr=tail;
while(curr){
printf("%d\t",curr->data);
curr=curr->prev;
}
}
}
//method to add node at front
node *add_beg(node *head,node *tail){
node *temp;
temp=(node*)malloc(sizeof(node));
if(temp==NULL){
printf("\nMemory Allocation is failed...");
exit(0);
}
printf("\nEnter data:");
scanf("%d",&temp->data);
temp->next=head;
temp->prev=NULL;
head->prev=temp;
head=temp;
return head;
}
//method to add node at end
node *add_end(node *head,node *tail){
node *temp;
temp=(node*)malloc(sizeof(node));
if(temp==NULL){
printf("\nMemory Allocation is failed...");
exit(0);
}
printf("\nEnter data:");
scanf("%d",&temp->data);
temp->next=NULL;
tail->next=temp;
temp->prev=tail;
tail=temp;
return tail;
}
//method to add node after kth node
void add_after_k(node *head,int k,node **tail){
 node *c=head,*temp;
 //loop to go to the position
 while(--k&&c->next!=NULL)
 c=c->next;
 //if the position do exist
 if(c->next!=NULL)
 {
 temp=(node*)malloc(sizeof(node));
 if(temp==NULL)
 printf("\nMemory allocation is not possible!!!");
 else
 {
 printf("\nEnter the data:");
 scanf("%d",&temp->data);
 temp->next=c->next;
 temp->prev=c;
 c->next->prev=temp;
 c->next=temp;
 }
 }
 else if(c->next==NULL&&k==0)
*tail=add_end(head,*tail);
 else
 printf("\nWrong Position...");
}
//method to add after a value
void add_after_val(node **head,int k,node **tail){
 node *c=*head,*temp;
 while(c){
 if(c->data==k){
 break;
 }
 c=c->next;
 }
 if(c==NULL){
 printf("\nValue not found...");
 }
 else{
temp=(node*)malloc(sizeof(node));
if(temp==NULL){
 printf("\nMemory allocation failed...");
 exit(0);
}
printf("\nEnter data:");
scanf("%d",&temp->data);
temp->next=NULL;
temp->prev=NULL;
if(c->next==NULL){
c->next=temp;
temp->prev=c;
*tail=temp;
}
else{
 temp->next=c->next;
 temp->prev=c;
 c->next->prev=temp;
 c->next=temp;
}
 }
}
//method to add before kth node
void add_before_k(node **head,int k,node **tail){
 node *c=*head,*temp;
 --k;
if(k==0){
*head=add_beg(*head,*tail);
return;
}
 //loop to go to the position
 while(--k&&c->next!=NULL)
 c=c->next;
 //if the position do exist
 if(c->next!=NULL)
 {
 temp=(node*)malloc(sizeof(node));
 if(temp==NULL)
 printf("\nMemory allocation is not possible!!!");
 else
 {
 printf("\nEnter the data:");
 scanf("%d",&temp->data);
 temp->next=c->next;
 temp->prev=c;
 c->next->prev=temp;
 c->next=temp;
 }
 }
 else
 printf("\nWrong Position...");
}
//method to add before a value
void add_before_val(node **head,int k,node **tail){
 node *c=*head,*temp,*p=NULL;
 if((*head)->data==k){
*head=add_beg(*head,*tail);
return;
 }
 while(c){
 if(c->data==k){
 break;
 }
 p=c;
 c=c->next;
 }
 if(c==NULL){
 printf("\nValue not found...");
 }
 else{
 temp=(node*)malloc(sizeof(node));
 if(temp==NULL)
 printf("\nMemmory allocation failed...");
 else{
 printf("\nEnter data:");
 scanf("%d",&temp->data);
 temp->next=p->next;
 temp->prev=p;
 p->next->prev=temp;
 p->next=temp;
 }
 }
}
//method to delete front node
node *del_beg(node *head){
 node *temp;
 if(head==NULL)
 return NULL;
 temp=head;
 head=head->next;
 temp->next=NULL;
 head->prev=NULL;
 free(temp);
 return head;
}
//method to delete last node
node *del_end(node *tail){
 node *temp;
 if(tail==NULL)
 return NULL;

 temp=tail;
 tail=tail->prev;
 temp->prev=NULL;
 tail->next=NULL;
 free(temp);
 return tail;
}
//method to delete after kth node
void del_after_k(node *head,int k){
 node *c=head,*temp;
 //loop to go to the position
 while(--k&&c->next!=NULL)
 c=c->next;
 //if the position do exist
 if(c->next!=NULL)
 {
 temp=c->next;
 c->next=temp->next;
 temp->next->prev=c;
 temp->next=NULL;
 temp->prev=NULL;
 free(temp);
 }
 else
 printf("\nWrong Position...");
}
//method to delete before kth node
void del_before_k(node *head,int k){
 node *c=head,*temp;
 if(k==1){
 printf("\nWrong Position...");
 return;
 }
 if(k==2)
 {
 printf("\nCan be handled by another case...");
 return;
 }
 k-=2;
 //loop to go to the position
 while(--k&&c->next!=NULL)
 c=c->next;
 //if the position do exist
 if(c->next!=NULL)
 {
 temp=c->next;
 c->next=temp->next;
 temp->next->prev=c;
 temp->next=NULL;
 temp->prev=NULL;
 free(temp);
 }
 else
 printf("\nWrong Position...");
}
//method to delete kth node
void del_k(node **head,int k,node **tail){
 node *c=*head,*temp;
 if(k==1)
 {
 *head=del_beg(*head);
 return;
 }
 --k;
 //loop to go to the position
 while(--k&&c->next!=NULL)
 c=c->next;
 //if the position do exist
 if(c->next!=NULL)
 {
 temp=c->next;
 c->next=temp->next;
 //if the deleting node is not the tail node
 if(temp->next!=NULL)
 temp->next->prev=c;
 //if deleting node is tail node
 if(temp->next==NULL)
 *tail=(*tail)->prev;
 temp->next=NULL;
 temp->prev=NULL;
 free(temp);
 }
 /*else if(c->next==NULL&&k==0){
*tail=del_end(*tail);
 }*/
 else
 printf("\nWrong Position...");
}
//method to delete a specified value
void del_val(node **head,node **tail,int val){
node *c,*temp,*p=NULL;
//if the value is present at head node
if((*head)->data==val){
*head=del_beg(*head);
return;
}
if((*tail)->data==val){
*tail=del_end(*tail);
return;
}
c=*head;
//loop to search the value
while(c->next){
p=c;
c=c->next;
if(c->data==val){
break;
}
}
//if value found,delete the node
if(c->next!=NULL){
temp=c;
p->next=c->next;
c->next->prev=p;
free(temp);
}
//otherwise value not found
else{
printf("\nValue not found...");
}
}
//reverse the linked list
void reverse(node **head,node **tail){
node *temp,*prev=NULL,*c=*head;
while(c){
temp=c->prev;
c->prev=c->next;
c->next=temp;
c=c->prev;
}
*tail=*head;
if(temp!=NULL)
*head=temp->prev;
}
int main(){
int ch,k;
node *head=NULL,*tail=NULL;
printf("\n1.Create Doubly linked list\n2.Display\n3.Insert at front\n4.Insert at end");
printf("\n5.Insert a node after kth node\n6.Insert a node after a value\n7.Insert a node before kth node");
printf("\n8.Insert a node before a value\n9.Delete First Node\n10.Delete Last Node\n11.Delete a node after kth node");
printf("\n12.Delete a node before kth node\n13.Delete kth node\n14.Delete a node containing a specified value");
printf("\n15.Find Reverse");
do{
printf("\nEnter your choice:");
scanf("%d",&ch);
switch(ch){
case 1:
create(&head,&tail);
break;
case 2:
display(head,tail);
break;
case 3:
head=add_beg(head,tail);
break;
case 4:
tail=add_end(head,tail);
break;
case 5:
printf("\nEnter k:");
scanf("%d",&k);
add_after_k(head,k,&tail);
break;
 case 6:
printf("\nEnter value:");
scanf("%d",&k);
add_after_val(&head,k,&tail);
break;
 case 7:
printf("\nEnter k:");
scanf("%d",&k);
add_before_k(&head,k,&tail);
break;
 case 8:
printf("\nEnter value:");
scanf("%d",&k);
add_before_val(&head,k,&tail);
break;
 case 9:
head=del_beg(head);
break;
 case 10:
tail=del_end(tail);
break;
case 11:
 printf("\nEnter k:");
scanf("%d",&k);
 del_after_k(head,k);
 break;
case 12:
 printf("\nEnter k:");
 scanf("%d",&k);
 del_before_k(head,k);
 break;
case 13:
 printf("\nEnter k:");
 scanf("%d",&k);
 del_k(&head,k,&tail);
 break;
case 14:
 printf("\nEnter value:");
 scanf("%d",&k);
 del_val(&head,&tail,k);
 break;
case 15:
 reverse(&head,&tail);
 break;
}
}while(ch>=1&&ch<=15);
return 0;
}
