echo -e "Home directory=\c"
echo ~
echo "Operating System type=$(uname)"
echo "Operating System version=$( cat /etc/issue.net)"
echo "Kernel version=$(uname -r)"
echo "Current path setting=$PATH"
